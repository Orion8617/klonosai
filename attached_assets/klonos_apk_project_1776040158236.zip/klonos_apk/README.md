# KlonOS Layer 5.0 — Sovereign SNN Browser

**Glial SNN Janitor Swarm · ClonEngine · Juan José Salgado Fuentes**

## ¿Qué es?

KlonOS es una PWA Android que implementa una enjambre de agentes
SNN (Spiking Neural Networks) que patrullan el DOM del navegador,
detectando y eliminando nodos de "basura" (scripts huérfanos,
fugas de memoria, telemetría pesada).

Inspirado biológicamente en los **astrocitos** — células gliales
que limpian sinapsis muertas y reciclan neurotransmisores en el
cerebro real.

## Innovaciones ClonEngine activas

- **Izhikevich RS/FS/CH/IB** — 4 tipos de neuronas reales
- **Maya Vigesimal Q20** — pesos cuantizados en 20 niveles
- **Pascal Cascade** — prioridad de limpieza por posición en anillo
- **HexVertex 6-bit** — arquetipo hexagonal rotante en cada spike
- **Bilateral κ=0.30** — acoplamiento hemisférico izq↔der
- **Schumann 7.83Hz** — phase-lock con resonancia terrestre
- **R-STDP reward** — dopamina sube con cada limpieza exitosa

## Build rápido

```bash
# 1. Instalar Android Studio: https://developer.android.com/studio
# 2. Clonar/descomprimir este proyecto
# 3. Ejecutar:
chmod +x BUILD.sh && ./BUILD.sh
# 4. Instalar en teléfono:
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

## Alternativa: Android Studio

1. Abrir `android/` como proyecto en Android Studio
2. `Build → Build APK(s)`
3. La APK aparece en `android/app/build/outputs/apk/`

## Arquitectura

```
www/index.html    ← KlonOS PWA (Capacitor WebView)
android/          ← Proyecto Android nativo
  app/src/main/
    MainActivity.kt    ← WebView con hardware acceleration
    AndroidManifest.xml
    assets/public/     ← www/ copiado aquí en build
```

## Requisitos

- Android 8.0+ (API 26+)
- JDK 17+
- Android SDK (via Android Studio)

---

*ClonEngine Project · New Orleans · Apache 2.0*
