// KlonOS Service Worker — Offline-first
const CACHE = 'klonos-v5.0.0';
const ASSETS = ['/index.html', '/manifest.json'];

self.addEventListener('install', e =>
    e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)))
);
self.addEventListener('fetch', e =>
    e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)))
);
