#!/bin/bash
# ═══════════════════════════════════════════════════════
# KlonOS Layer 5.0 — Build Script
# Genera APK debug + release en un solo comando
# Requiere: Android Studio o Android SDK instalado
#
# USO:
#   chmod +x BUILD.sh
#   ./BUILD.sh
# ═══════════════════════════════════════════════════════

set -e
echo "🧠 KlonOS Layer 5.0 — Build APK"
echo "=================================="

# Verificar Java
if ! command -v java &> /dev/null; then
    echo "❌ Java no encontrado. Instala JDK 17+"
    exit 1
fi

# Verificar ANDROID_HOME
if [ -z "$ANDROID_HOME" ]; then
    # Intentar rutas comunes
    if [ -d "$HOME/Android/Sdk" ]; then
        export ANDROID_HOME="$HOME/Android/Sdk"
    elif [ -d "/usr/local/android-sdk" ]; then
        export ANDROID_HOME="/usr/local/android-sdk"
    else
        echo "❌ ANDROID_HOME no configurado."
        echo "   Instala Android Studio y configura ANDROID_HOME"
        exit 1
    fi
fi

export PATH="$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools:$PATH"
echo "✅ Android SDK: $ANDROID_HOME"
echo "✅ Java: $(java -version 2>&1 | head -1)"

# Copiar assets web
echo "📦 Copiando assets web..."
cp -r www/* android/app/src/main/assets/public/

# Build APK debug
echo "🔨 Compilando APK debug..."
cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon --stacktrace

echo ""
echo "✅ APK generada:"
find . -name "*.apk" -print
echo ""
echo "📱 Para instalar en tu teléfono:"
echo "   adb install app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "🌐 KlonOS Layer 5.0 · ClonEngine · Juan José Salgado Fuentes"
