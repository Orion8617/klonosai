# KlonOS ProGuard rules
-keep class com.klonos.layer5.** { *; }
-keep class com.getcapacitor.** { *; }
-keepattributes *Annotation*
-dontwarn com.getcapacitor.**
