package com.klonos.layer5

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.getcapacitor.BridgeActivity

/**
 * KlonOS Layer 5.0 — MainActivity
 * Glial SNN Janitor Swarm · Juan José Salgado Fuentes
 * ClonEngine · Izhikevich · Maya Q20 · Schumann 7.83Hz
 */
class MainActivity : BridgeActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Pantalla completa — sin status bar interrumpiendo el canvas
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        // Configuración avanzada del WebView para SNN canvas
        val webView = bridge.webView
        webView.settings.apply {
            javaScriptEnabled     = true
            domStorageEnabled     = true
            allowFileAccess       = true
            mixedContentMode      = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            // Aceleración de hardware para canvas (crítico para animación SNN)
            setLayerType(WebView.LAYER_TYPE_HARDWARE, null)
            // Permite offscreen rendering del canvas
            offscreenPreRaster = true
        }

        // Mantener pantalla encendida durante el swarm activo
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onResume() {
        super.onResume()
        // Resumir el animation loop de los agentes SNN
        bridge.webView.onResume()
    }

    override fun onPause() {
        super.onPause()
        bridge.webView.onPause()
    }
}
