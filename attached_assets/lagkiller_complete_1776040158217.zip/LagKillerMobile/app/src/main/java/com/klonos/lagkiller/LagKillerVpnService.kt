package com.klonos.lagkiller

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * LagKillerVpnService — Ring-0 TUN Interceptor
 * Establece interfaz VPN y transfiere el TUN fd al core Rust.
 *
 * Pipeline:
 *   Android VPN API → TUN fd → JNI detachFd() → Rust SNN loop
 *   → Maya Q20 packet priority → rewrite/forward
 */
class LagKillerVpnService : VpnService() {

    companion object {
        private const val TAG         = "KlonOS-VPN"
        private const val NOTIF_ID    = 0xC896          // #00C896 verde ClonEngine
        private const val CHANNEL_ID  = "klonos_vpn"
        private const val MTU         = 1500

        // JNI: cargar la librería Rust compilada por cargo-ndk
        init { System.loadLibrary("lagkiller_engine") }
    }

    // JNI: punto de entrada en Rust
    private external fun startNativeRustLoop(fd: Int, mtu: Int): Int
    private external fun stopNativeRustLoop(): Unit

    private var vpnInterface: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var rustThread: Thread? = null

    // ── onStartCommand ──────────────────────────────────────────
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
        }

        // 1. Foreground notification obligatoria Android 8+
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())

        // 2. Construir interfaz VPN
        if (!buildVpnInterface()) {
            Log.e(TAG, "No se pudo establecer la interfaz VPN")
            stopSelf()
            return START_NOT_STICKY
        }

        // 3. Transferir fd a Rust en un hilo dedicado
        running.set(true)
        rustThread = Thread({
            val fd = vpnInterface?.detachFd() ?: run {
                Log.e(TAG, "fd nulo"); return@Thread
            }
            Log.i(TAG, "⚡ Ring-0 handoff: TUN fd=$fd → Rust SNN loop")
            // El loop Rust devuelve cuando se llama stopNativeRustLoop()
            val result = startNativeRustLoop(fd, MTU)
            Log.i(TAG, "Rust loop terminó con código: $result")
            running.set(false)
        }, "KlonOS-Rust-Loop").apply { isDaemon = true; start() }

        return START_STICKY
    }

    // ── Construir interfaz VPN ──────────────────────────────────
    private fun buildVpnInterface(): Boolean {
        return try {
            vpnInterface = Builder()
                .setSession("KlonOS LagKiller SNN")
                .setMtu(MTU)
                // Dirección IP del túnel virtual
                .addAddress("10.88.0.1", 32)
                // Interceptar TODO el tráfico IPv4 e IPv6
                .addRoute("0.0.0.0",  0)
                .addRoute("::", 0)
                // DNS propios para evitar fugas
                .addDnsServer("1.1.1.1")           // Cloudflare
                .addDnsServer("9.9.9.9")           // Quad9
                .addDnsServer("2606:4700:4700::1111") // Cloudflare IPv6
                // Excluir el propio paquete del túnel (evitar loop)
                .also { protect(0) }
                .establish()
            vpnInterface != null
        } catch (e: Exception) {
            Log.e(TAG, "Error buildVpnInterface: ${e.message}")
            false
        }
    }

    // ── Cleanup al destruir ──────────────────────────────────────
    override fun onDestroy() {
        Log.i(TAG, "🔴 Destruyendo LagKillerVpnService")
        stopNativeRustLoop()    // señal al loop Rust
        running.set(false)
        rustThread?.join(2000)  // esperar máx 2s
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }

    // ── Notificación foreground obligatoria ─────────────────────
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "KlonOS VPN Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "SNN Ring-0 Packet Interceptor activo"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, LagKillerVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        val mainIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("KlonOS LagKiller SNN")
            .setContentText("⚡ Ring-0 interceptor activo · Schumann 7.83Hz")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(mainIntent)
            .addAction(Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Detener", stopIntent
            ).build())
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.klonos.lagkiller.STOP"
    }
}
