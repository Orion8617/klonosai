plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace   = "com.klonos.lagkiller"
    compileSdk  = 34

    defaultConfig {
        applicationId = "com.klonos.lagkiller"
        minSdk        = 26
        targetSdk     = 34
        versionCode   = 5
        versionName   = "5.0.0"
        ndk { abiFilters += "arm64-v8a" }
    }

    sourceSets {
        getByName("main") { jniLibs.srcDir("src/main/jniLibs") }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// ── Compilar Rust core con cargo-ndk ANTES de assembleDebug/Release ──
tasks.register<Exec>("buildRustCore") {
    group       = "build"
    description = "Compila el motor Rust para arm64-v8a"
    workingDir  = file("../rust_core")
    commandLine(
        "cargo", "ndk",
        "-t", "arm64-v8a",
        "-o", "../app/src/main/jniLibs",
        "build", "--release"
    )
    doFirst { println("[KlonOS] ⚙️  Compilando Rust engine...") }
    doLast  { println("[KlonOS] ✅ lagkiller_engine.so generado") }
}

tasks.whenTaskAdded {
    if (name in listOf("assembleDebug", "assembleRelease", "bundleRelease")) {
        dependsOn("buildRustCore")
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.core:core-ktx:1.12.0")
}
