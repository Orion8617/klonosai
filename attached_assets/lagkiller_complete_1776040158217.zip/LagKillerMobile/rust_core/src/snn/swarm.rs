// ═══════════════════════════════════════════════════════════
//  SWARM AUTO-MAINTENANCE — Lógica de Autogestión SNN
//  ClonEngine · Juan José Salgado Fuentes
//
//  CORRECIONES vs snippet original:
//    ✅ Typo "swarn" → "swarm" corregido
//    ✅ SystemMetrics, calculate_pascal_deviation definidos
//    ✅ VIGESIMAL_WEIGHT usado correctamente con escala [0,1]
//    ✅ Schumann timing integrado
//    ✅ Result<> para manejo de errores Rust
//    ✅ STBP surrogate gradient en adjust_swarm_sensitivity
// ═══════════════════════════════════════════════════════════

use std::time::Duration;

const VIGESIMAL_WEIGHT: f32 = 1.0 / 9.5;  // Lloyd-Max = Tzolkin Gen280
const PASCAL_4: [f32; 5]   = [0.0625, 0.250, 0.375, 0.250, 0.0625];
const SCHUMANN_INTERVAL: Duration = Duration::from_micros(127_713); // 7.83Hz
const WINIK_CYCLE: u32 = 20;

/// Métricas del sistema DOM/Red capturadas por el Content Script
#[derive(Debug, Clone, Default)]
pub struct SystemMetrics {
    /// Profundidad del DOM en cada "columna" (para Pascal Cascade)
    pub dom_depth_map: Vec<f32>,
    /// Número de scripts de terceros detectados
    pub waste_script_count: u32,
    /// RAM estimada de elementos basura (KB)
    pub waste_kb: f32,
    /// Tasa de paquetes de red procesados (pps)
    pub packet_rate: f32,
    /// Latencia de red actual (ms)
    pub latency_ms: f32,
}

/// Estado de la cuadrilla SNN
#[derive(Debug)]
pub struct SwarmState {
    /// Threshold actual de disparo [0,1] — baja = más agresivo
    pub threshold:     f32,
    /// Nivel de dopamina global [0,1]
    pub dopamine:      f32,
    /// Ciclo WInik actual
    pub winik_cycle:   u32,
    /// Total de nodos limpiados
    pub cleaned_total: u64,
    /// Fase Schumann [0,1)
    pub schumann_phase: f32,
}

impl Default for SwarmState {
    fn default() -> Self {
        SwarmState {
            threshold:      0.5,    // umbral neutro al inicio
            dopamine:       0.5,
            winik_cycle:    0,
            cleaned_total:  0,
            schumann_phase: 0.0,
        }
    }
}

/// Calcula la desviación Pascal del mapa de profundidad del DOM.
/// Compara la distribución real con la distribución Pascal ideal [1,4,6,4,1].
/// Resultado en [0,1]: 0=DOM perfecto, 1=DOM completamente anómalo.
pub fn calculate_pascal_deviation(depth_map: &[f32]) -> f32 {
    if depth_map.is_empty() { return 0.0; }

    // Normalizar el depth_map a 5 "anillos" Pascal
    let rings = 5;
    let chunk = (depth_map.len() / rings).max(1);
    let mut actual = [0.0_f32; 5];

    for (ring, chunk_slice) in depth_map.chunks(chunk).take(5).enumerate() {
        let avg = chunk_slice.iter().sum::<f32>() / chunk_slice.len() as f32;
        actual[ring] = avg;
    }

    // Normalizar actual a suma=1 para comparar con Pascal
    let total: f32 = actual.iter().sum();
    if total < 1e-6 { return 0.0; }
    let actual_norm: [f32; 5] = actual.map(|v| v / total);

    // Desviación cuadrática media respecto a Pascal ideal
    let mse: f32 = actual_norm.iter().zip(PASCAL_4.iter())
        .map(|(a, p)| (a - p).powi(2))
        .sum::<f32>() / 5.0;

    // Cuantizar en base Maya Q20
    let level = (mse.sqrt().clamp(0.0, 1.0) * 19.0).round();
    level / 19.0
}

/// Ejecuta la limpieza distribuida de la cuadrilla.
/// En la arquitectura real, esto envía un mensaje al Content Script
/// para que los 4 agentes Izhikevich lancen un burst Gamma (40Hz).
pub fn execute_distributed_cleanup(state: &mut SwarmState) {
    // Burst Gamma: reducir threshold temporalmente
    // para que todos los agentes disparen más fácilmente
    state.threshold = (state.threshold * 0.7).max(0.15);
    state.cleaned_total += 1;

    // Reward R-STDP: limpieza exitosa → dopamina sube
    state.dopamine = (state.dopamine + 0.10).min(1.0);
}

/// STBP Surrogate Gradient — ajustar sensibilidad de la cuadrilla.
/// Si el sistema se ensucia rápido (waste_pressure alta),
/// baja el threshold (más agresivo).
/// Si está limpio, sube el threshold (más conservador).
///
/// h'(u) = max(0, 1 - |u / V_th|) — surrogate triangular
pub fn adjust_swarm_sensitivity(state: &mut SwarmState, waste_pressure: f32) {
    // Surrogate gradient
    let vth = 0.5_f32;
    let sg  = (1.0 - (waste_pressure / vth).abs()).max(0.0);

    // Error: queremos threshold proporcional a (1 - waste_pressure)
    // Más basura → threshold más bajo → más agresivo
    let target_threshold = 1.0 - waste_pressure;
    let error            = target_threshold - state.threshold;

    // STBP update: Δthreshold = lr × error × surrogate_gradient
    let lr = VIGESIMAL_WEIGHT * state.dopamine;  // lr modulado por dopamina
    state.threshold = (state.threshold + lr * error * sg).clamp(0.1, 0.9);
}

/// CORRECCION PRINCIPAL del snippet original:
/// Integra las 3 funciones con estado, Schumann timing y WInik.
pub fn swarm_auto_maintenance(
    metrics:   &SystemMetrics,
    state:     &mut SwarmState,
    dt_ms:     f32,
) {
    // Actualizar fase Schumann
    state.schumann_phase += dt_ms / 127.713; // 7.83Hz
    let schumann_fired = state.schumann_phase >= 1.0;
    if schumann_fired {
        state.schumann_phase -= 1.0;

        // WInik cycle cada 20 pulsos Schumann (~2.55s)
        if state.schumann_phase < 0.1 {
            let prev_winik = state.winik_cycle;
            state.winik_cycle = (state.winik_cycle + 1) % WINIK_CYCLE;
            if state.winik_cycle < prev_winik {
                // Ciclo completo: reset suave de dopamina hacia neutral
                state.dopamine = state.dopamine * 0.8 + 0.5 * 0.2;
            }
        }
    }

    // Calcular presión Pascal del DOM
    let waste_pressure = calculate_pascal_deviation(&metrics.dom_depth_map);

    // Presión adicional por scripts y latencia
    let net_pressure = (waste_pressure
        + metrics.waste_script_count as f32 * VIGESIMAL_WEIGHT
        + (metrics.latency_ms / 1000.0) * 0.1
    ).min(1.0);

    // Umbral dinámico: VIGESIMAL_WEIGHT = 0.1052 + modulación dopamina
    // Cuando dopamina es alta, el umbral sube (menos alarmista)
    let dynamic_threshold = VIGESIMAL_WEIGHT * (1.0 + state.dopamine * 0.5);

    if net_pressure > dynamic_threshold {
        // La cuadrilla coordina burst Gamma de limpieza
        execute_distributed_cleanup(state);

        // STBP ajusta sensibilidad con surrogate gradient
        // FIX: era "adjust_swarn_sensitivity" — typo corregido
        adjust_swarm_sensitivity(state, net_pressure);
    }

    // Dopamina decae naturalmente
    state.dopamine = (state.dopamine * 0.9998).clamp(0.1, 1.0);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pascal_deviation_perfect_dom() {
        // DOM perfectamente distribuido → desviación ~0
        let perfect = vec![0.0625, 0.25, 0.375, 0.25, 0.0625];
        let dev = calculate_pascal_deviation(&perfect);
        assert!(dev < 0.1, "DOM perfecto debe tener desviación baja: {dev}");
    }

    #[test]
    fn pascal_deviation_worst_dom() {
        // DOM todo concentrado en ring 4 → alta desviación
        let worst = vec![0.0, 0.0, 0.0, 0.0, 1.0];
        let dev = calculate_pascal_deviation(&worst);
        assert!(dev > 0.3, "DOM peor caso debe tener desviación alta: {dev}");
    }

    #[test]
    fn swarm_threshold_decreases_with_pressure() {
        let mut state = SwarmState::default();
        let initial_threshold = state.threshold;
        adjust_swarm_sensitivity(&mut state, 0.9); // alta presión
        assert!(state.threshold < initial_threshold,
            "Alta presión debe bajar el threshold");
    }

    #[test]
    fn vigesimal_weight_is_lloyd_max() {
        let expected = 1.0 / 9.5_f32;
        assert!((VIGESIMAL_WEIGHT - expected).abs() < 1e-6);
    }
}
