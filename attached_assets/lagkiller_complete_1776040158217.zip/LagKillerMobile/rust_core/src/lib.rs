// ═══════════════════════════════════════════════════════════════
//  LAGKILLER ENGINE — Rust JNI Core
//  ClonEngine · Juan José Salgado Fuentes
//  
//  Pipeline por paquete:
//    1. Read TUN fd (raw IPv4/IPv6)
//    2. Parse header → extract priority signals
//    3. Maya Q20 quantize → discrete priority level
//    4. Schumann scheduler → decide si procesar ahora
//    5. Pascal Cascade → calcular boost
//    6. Write back (forward sin latencia)
//
//  Schumann Phase-Lock: 7.83Hz gate en el loop principal
// ═══════════════════════════════════════════════════════════════

use jni::objects::JClass;
use jni::sys::jint;
use jni::JNIEnv;
use libc::{read, write, select, fd_set, timeval, FD_ZERO, FD_SET, FD_ISSET};
use std::os::unix::io::RawFd;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

// ── ClonEngine Constants ─────────────────────────────────────────
const MAYA_LEVELS     : f32 = 20.0;
const VIGESIMAL_WEIGHT: f32 = 1.0 / 9.5;  // Lloyd-Max óptimo
const SCHUMANN_HZ     : f64 = 7.83;
const SCHUMANN_US     : u64 = (1_000_000.0 / SCHUMANN_HZ) as u64; // 127,713 μs
const BILATERAL_KAPPA : f32 = 0.30;
const WINIK_CYCLE     : u32 = 20;

// Pesos Pascal n=4 normalizados
const PASCAL: [f32; 5] = [0.0625, 0.250, 0.375, 0.250, 0.0625];

// ── Señal de parada thread-safe ──────────────────────────────────
static RUNNING: AtomicBool = AtomicBool::new(false);

// ── Maya Vigesimal Quantization ──────────────────────────────────
#[inline(always)]
fn maya_q20(v: f32) -> f32 {
    let level = (v * MAYA_LEVELS).round().clamp(0.0, MAYA_LEVELS - 1.0);
    level / MAYA_LEVELS
}

// ── Pascal Cascade weight for packet ring ───────────────────────
// ring=0: paquetes críticos (DNS, ACK pequeños)
// ring=4: basura (telemetría, ads, beacons)
#[inline(always)]
fn pascal_weight(ring: usize) -> f32 {
    PASCAL[ring.min(4)]
}

// ── IPv4 Packet Inspector ────────────────────────────────────────
#[derive(Debug, Default)]
struct PacketMeta {
    protocol:    u8,   // 6=TCP, 17=UDP, 1=ICMP
    src_ip:      u32,
    dst_ip:      u32,
    src_port:    u16,
    dst_port:    u16,
    size_bytes:  usize,
    ring:        usize, // Pascal ring asignado
    priority:    f32,   // Maya Q20 priority [0,1]
    is_ipv6:     bool,
}

impl PacketMeta {
    fn parse(buf: &[u8]) -> Self {
        let mut meta = PacketMeta {
            size_bytes: buf.len(),
            ..Default::default()
        };
        if buf.is_empty() { return meta; }

        let version = (buf[0] >> 4) & 0xF;

        if version == 4 && buf.len() >= 20 {
            // IPv4
            meta.protocol = buf[9];
            meta.src_ip   = u32::from_be_bytes([buf[12],buf[13],buf[14],buf[15]]);
            meta.dst_ip   = u32::from_be_bytes([buf[16],buf[17],buf[18],buf[19]]);
            let ihl       = ((buf[0] & 0xF) * 4) as usize;
            if meta.protocol == 6 || meta.protocol == 17 {
                // TCP/UDP: leer puertos
                if buf.len() >= ihl + 4 {
                    meta.src_port = u16::from_be_bytes([buf[ihl], buf[ihl+1]]);
                    meta.dst_port = u16::from_be_bytes([buf[ihl+2], buf[ihl+3]]);
                }
            }
        } else if version == 6 && buf.len() >= 40 {
            meta.is_ipv6  = true;
            meta.protocol = buf[6]; // next header
        }

        // Asignar Pascal ring según tipo de tráfico
        meta.ring = classify_ring(&meta);
        // Maya Q20 priority: ring 0 → alta prioridad, ring 4 → baja
        let raw_priority = 1.0 - (meta.ring as f32 / 4.0);
        meta.priority = maya_q20(raw_priority);
        meta
    }
}

fn classify_ring(m: &PacketMeta) -> usize {
    // Ring 0 — DNS (puerto 53): crítico, procesar siempre primero
    if m.dst_port == 53 || m.src_port == 53 { return 0; }
    // Ring 0 — ACKs pequeños (< 60 bytes): críticos para latencia
    if m.size_bytes < 60 { return 0; }
    // Ring 1 — Gaming (UDP puertos comunes)
    if m.protocol == 17 {
        let p = m.dst_port;
        if (3074..=3076).contains(&p) || p == 27015 || p == 7777 { return 1; }
    }
    // Ring 1 — HTTPS/443
    if m.dst_port == 443 || m.src_port == 443 { return 1; }
    // Ring 2 — HTTP/80
    if m.dst_port == 80 || m.src_port == 80 { return 2; }
    // Ring 3 — UDP genérico
    if m.protocol == 17 { return 3; }
    // Ring 4 — Todo lo demás (posible telemetría)
    4
}

// ── SNN State (Izhikevich simplificado para packet scoring) ──────
struct SnnPacketNeuron {
    v: f32, u: f32,
    a: f32, b: f32, c: f32, d: f32,
    dopamine:      f32,
    total_packets: u64,
    total_bytes:   u64,
    winik_count:   u32,
}

impl SnnPacketNeuron {
    fn new() -> Self {
        SnnPacketNeuron {
            v: -65.0, u: -13.0,
            a: 0.02, b: 0.2, c: -65.0, d: 8.0,
            dopamine: 0.5,
            total_packets: 0,
            total_bytes: 0,
            winik_count: 0,
        }
    }

    /// Procesar un paquete: actualizar membrana y detectar spike
    /// La corriente I viene del Pascal priority del paquete
    fn process_packet(&mut self, meta: &PacketMeta, pascal_w: f32) -> bool {
        self.total_packets += 1;
        self.total_bytes   += meta.size_bytes as u64;

        let I = meta.priority * pascal_w * 30.0;

        // Izhikevich split-step
        self.v += 0.5 * (0.04*self.v*self.v + 5.0*self.v + 140.0 - self.u + I);
        self.u += 0.5 * self.a * (self.b*self.v - self.u);
        self.v += 0.5 * (0.04*self.v*self.v + 5.0*self.v + 140.0 - self.u + I);
        self.u += 0.5 * self.a * (self.b*self.v - self.u);

        let threshold = 30.0 * if meta.ring == 0 { BILATERAL_KAPPA+0.5 } else { 1.0 };

        if self.v >= threshold {
            // Spike: paquete prioritario — dopamina sube
            self.v = self.c; self.u += self.d;
            self.dopamine = (self.dopamine + 0.05).min(1.0);
            true
        } else {
            self.dopamine *= 0.9998;
            false
        }
    }
}

// ── MAIN RUST LOOP — JNI Entry Point ─────────────────────────────
#[no_mangle]
pub extern "system" fn Java_com_klonos_lagkiller_LagKillerVpnService_startNativeRustLoop(
    _env: JNIEnv,
    _class: JClass,
    fd: jint,
    _mtu: jint,
) -> jint {
    RUNNING.store(true, Ordering::SeqCst);
    let tun_fd = fd as RawFd;
    start_metal_loop(tun_fd) as jint
}

#[no_mangle]
pub extern "system" fn Java_com_klonos_lagkiller_LagKillerVpnService_stopNativeRustLoop(
    _env: JNIEnv,
    _class: JClass,
) {
    RUNNING.store(false, Ordering::SeqCst);
}

fn start_metal_loop(tun_fd: RawFd) -> i32 {
    let mut packet    = [0u8; 65535];
    let mut snn       = SnnPacketNeuron::new();
    let mut winik_t   = Instant::now();
    let mut schumann_t= Instant::now();
    let     schumann_period = Duration::from_micros(SCHUMANN_US);
    let     winik_period    = Duration::from_secs(3); // ~WInik 20 × 127ms

    while RUNNING.load(Ordering::Relaxed) {
        // ── select() con timeout Schumann ────────────────────────
        // En lugar de blocking read, usar select con timeout de 1ms
        // Esto permite verificar RUNNING regularmente
        let bytes_ready = wait_for_read(tun_fd, 1); // 1ms timeout

        if bytes_ready > 0 {
            let n = unsafe {
                read(tun_fd, packet.as_mut_ptr() as *mut libc::c_void, packet.len())
            };

            if n < 0 {
                // Error de lectura — fd cerrado o error de red
                eprintln!("[KlonOS Rust] read error: fd cerrrado");
                break;
            }
            if n == 0 { continue; }

            let data = &packet[..n as usize];

            // ── SNN Packet Analysis ─────────────────────────────
            let meta     = PacketMeta::parse(data);
            let pascal_w = pascal_weight(meta.ring);
            let spiked   = snn.process_packet(&meta, pascal_w);

            // ── Forward: write de vuelta al TUN ─────────────────
            // Si el paquete generó spike (alta prioridad): forward inmediato
            // Si no: forward de todas formas (no bloqueamos tráfico legítimo)
            let wrote = unsafe {
                write(tun_fd, data.as_ptr() as *const libc::c_void, n as usize)
            };
            if wrote < 0 { break; }
        }

        // ── Schumann Phase (7.83Hz) ──────────────────────────────
        if schumann_t.elapsed() >= schumann_period {
            schumann_t = Instant::now();
            // Bilateral decay
            snn.dopamine = (snn.dopamine * (1.0 - BILATERAL_KAPPA*0.01))
                          + (0.5 * BILATERAL_KAPPA*0.01);
            snn.dopamine = snn.dopamine.clamp(0.1, 1.0);
        }

        // ── WInik Sacrifice (cada ~3s) ───────────────────────────
        if winik_t.elapsed() >= winik_period {
            winik_t = Instant::now();
            snn.winik_count += 1;
            // En el WInik: reset parcial de membrana (limpieza)
            snn.v = snn.c;
            eprintln!(
                "[KlonOS] 🔥 WInik #{} · pkts:{} · bytes:{}KB · DA:{:.0}%",
                snn.winik_count,
                snn.total_packets,
                snn.total_bytes/1024,
                snn.dopamine*100.0
            );
        }
    }

    0 // código de retorno OK
}

// ── select() wrapper para timeout no-bloqueante ──────────────────
fn wait_for_read(fd: RawFd, timeout_ms: i64) -> i32 {
    unsafe {
        let mut read_fds: fd_set = std::mem::zeroed();
        FD_ZERO(&mut read_fds);
        FD_SET(fd, &mut read_fds);
        let mut tv = timeval {
            tv_sec:  0,
            tv_usec: timeout_ms * 1000,
        };
        select(fd+1, &mut read_fds, std::ptr::null_mut(), std::ptr::null_mut(), &mut tv)
    }
}
